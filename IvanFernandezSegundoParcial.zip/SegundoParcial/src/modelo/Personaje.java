package modelo;

public class Personaje implements Comparable<Personaje>, CSVSerializable {

    private int id;
    private String nombre;
    private Clase clase;
    private int nivel;

    public Personaje(int id, String nombre, Clase clase, int nivel) {
        this.id = id;
        this.nombre = nombre;
        this.clase = clase;
        this.nivel = nivel;
    }

    public int getNivel() {
        return nivel;
    }

    public Clase getClase() {
        return clase;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return "Personaje{" + "id=" + id + ", nombre=" + nombre + ", clase=" + clase + ", nivel=" + nivel + '}';
    }

    @Override
    public int compareTo(Personaje p) {
        return this.nombre.compareTo(p.nombre);
    }
    
    @Override
    public String toCSV() {
        return id + "," + nombre + "," + clase.toString() + "," + nivel;
    }

    public static Personaje fromCSV(String pjCSV) {
        Personaje aux = null;
        String[] values = pjCSV.split(",");
        if (values.length == 4) {
            int id = Integer.parseInt(values[0]);
            String nombre = values[1];
            Clase clase = Clase.valueOf(values[2]);
            int nivel = Integer.parseInt(values[3]);
            aux = new Personaje(id, nombre, clase, nivel);
        }
        return aux;
    }

    

}
