package servicio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import modelo.CSVSerializable;
import modelo.Personaje;

public class Inventario<T extends CSVSerializable> {

    private List<T> items = new ArrayList<>();

    public void agregar(T item) {
        if (item == null) {
            throw new IllegalArgumentException("Error: No se admiten items null");
        }
        items.add(item);
    }

    public void eliminar(int id) {
        checkearId(id);
        items.remove(id);
    }
    
    private void checkearId(int id) {
        if (id < 0 || id >= items.size()) {
            throw new IndexOutOfBoundsException("Error: ID invalido");
        }
    }
    
    public void paraCadaElemento(Consumer<T> accion) {
            for (T item : items) {
                accion.accept(item);
            }
        }
    
    public void ordenar() {
        if (items.isEmpty()) {
            throw new IllegalStateException("Error: No se puede ordenar una lista vacia");
        }
        items.sort(null);
    }

    public void ordenar(Comparator<T> comparator) {
        items.sort(comparator);
    }

    public List<T> filtrar(Predicate<T> criterio) {
        if (criterio == null) {
            throw new IllegalArgumentException("Error: El criterio no puede ser null");
        }
        List<T> aux = new ArrayList<>();
        for (T item : items) {
            if (criterio.test(item)) {
                aux.add(item);
            }
        }
        return aux;
    }
    
    public void transformar(Function<T, T> transformador) {
        if (transformador == null) {
            throw new IllegalArgumentException("Error: El transformador no puede ser null");
        }
        for (int i = 0; i < items.size(); i++) {
            T elementoTransformado = transformador.apply(items.get(i));
            items.set(i, elementoTransformado);
        }
    }
    
    
    public void guardarEnArchivo(String path) throws IOException {
        try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(path))) {
            output.writeObject(items);
        }
    }

    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))) {
            items = (List<T>) input.readObject();
        }
    }

    public void guardarEnCSV(String path) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(path))) {
            // headers
            writer.write("id,nombre,clase,nivel");
            writer.newLine();

            for (T item : items) {
                writer.write(item.toCSV());
                writer.newLine();
            }
        }
    }

    public void cargarDesdeCSV(String path, Function<String, T> transformador) throws IOException {
        items.clear();
        File archivo = new File(path);
        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            br.readLine();
            while ((linea = br.readLine()) != null) {
                items.add(transformador.apply(linea));
            }
        }
    }

    public void clearList() {
        items.clear();
    }
}
